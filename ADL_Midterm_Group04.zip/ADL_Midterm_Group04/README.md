
# KMNIST Classifier with TensorFlow

This repository contains code for training and evaluating a neural network classifier on the KMNIST dataset using TensorFlow.

## Features

- **Model Architecture**: Dense neural network with configurable dropout layers.
- **Optimizers**: Adam, RMSprop, AdamW.
- **Training**: Trains models with different optimizers and hyperparameters.
- **Visualization**: Interactive plots using Plotly to visualize model accuracy and loss over epochs.
- **Search Technique**: Utilizes GridSearchCV or RandomizedSearchCV for hyperparameter tuning.

## Usage

### Running the Code in Google Colab

1. Open Google Colab: Go to [Google Colab](https://colab.research.google.com/).
   
2. Upload Notebook: Upload the provided Jupyter notebook (`*.ipynb`) ("ADL_Midterm_Project_Group04") to Google Colab.

3. Set Up Environment:
   - Ensure TensorFlow and other required libraries are installed. If not, install them using:
     ```python
     !pip install tensorflow tensorflow-datasets scikit-learn matplotlib plotly
     ```

4. Run the Notebook:
   - Execute each cell in the notebook sequentially by clicking the play button ▶️ or pressing Shift+Enter.
   - The notebook will train models with different optimizers and display evaluation metrics and visualizations inline.

5. View Results:
   - Monitor the output in the notebook for model summaries, training progress, evaluation metrics, and interactive plots.

6. Save The Work:
   - Save a copy of the notebook with the results by clicking `File` > `Save a copy in Drive...` in Google Colab.
